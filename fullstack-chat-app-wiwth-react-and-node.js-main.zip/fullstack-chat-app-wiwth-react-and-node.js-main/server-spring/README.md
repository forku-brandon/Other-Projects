Install `mvn clean install`
Run `mvn spring-boot:run`
